<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing Php Function with Parameter</title>
</head>
<body>
    <h2> php with two parameter</h2>
    <?php
    /* Defining Use Paramater*/
        function addFunction($num1, $num2) {
            $sum = $num1 +$num2;
            echo "sum of the two number : $sum";
        }
/* Call function and Value num1 and num2 */
        addFunction(10,30);
    ?>
</body>
</html>